package Theory.ComparableTest;

public class Person implements Comparable<Person> {
    private String name;
    private int age;

    @Override
    public String toString() {
        return "Person{" +
                "name='" + name + '\'' +
                ", age=" + age +
                '}';
    }

    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public Person() {

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    @Override
    public int compareTo(Person o) {
        int result = this.getAge()-o.getAge();
        if (result==0){
            return this.getName().charAt(0) - o.getName().charAt(0);
        }
        return result;
    }
}
