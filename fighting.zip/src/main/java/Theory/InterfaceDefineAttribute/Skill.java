package Theory.InterfaceDefineAttribute;

public interface Skill {
    void use();
}
