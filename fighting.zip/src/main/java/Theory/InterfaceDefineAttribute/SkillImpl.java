package Theory.InterfaceDefineAttribute;

public class SkillImpl implements Skill {
    @Override
    public void use() {
        System.out.println("biu ~ biu ~ biu~ ");
    }
}
