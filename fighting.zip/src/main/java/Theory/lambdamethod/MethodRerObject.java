package Theory.lambdamethod;

public class MethodRerObject {
    public void printUpperCaseString(String s){
        System.out.println(s.toUpperCase());
    }
}
