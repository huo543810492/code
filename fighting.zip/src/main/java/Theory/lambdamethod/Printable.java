package Theory.lambdamethod;

@FunctionalInterface
public interface Printable {
    void print(String str);
}
