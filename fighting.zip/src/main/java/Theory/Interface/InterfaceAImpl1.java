package Theory.Interface;

public class InterfaceAImpl1 implements InterfaceA{

    @Override
    public void methodA() {
        System.out.println("InterfaceAImpl1 实现了接口");
    }
}
