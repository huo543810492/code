package Theory.MultExtendsForInterface;

public class InterfaceChildImpl implements InterfaceChild {

    @Override
    public void methodChild() {

    }

    @Override
    public void methodA() {

    }

    @Override
    public void methodB() {

    }
}
