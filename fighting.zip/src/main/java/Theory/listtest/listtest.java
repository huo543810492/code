package Theory.listtest;

public class listtest
{
    public static void main(String[] args) {
        lista a = new lista();
        a.tryAdd("abaa");
    }
}
