package Theory.Factory;

public interface Notification {
    void notifyUser();
}
