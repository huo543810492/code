package Theory.Enum;

public enum  Enum {
    INSTANCE,INSTANCE2;

    public void doSomething(){
        System.out.println("do something");
    }

}
