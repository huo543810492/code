package Theory.Enum;

public class test {
//    public static void main(String[] args) {
//        java.lang.Enum.INSTANCE.doSomething();
//        java.lang.Enum.INSTANCE2.doSomething();
//    }
}
