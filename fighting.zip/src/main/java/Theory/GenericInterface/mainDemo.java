package Theory.GenericInterface;

public class mainDemo
{
    public static void main(String[] args) {
        GenericInterfaceImpl1 genericInterfaceImpl1 = new GenericInterfaceImpl1();
        genericInterfaceImpl1.method("伊东美咲");

        GenericInterfaceImpl2 genericInterfaceImpl2 = new GenericInterfaceImpl2();
        genericInterfaceImpl2.method("伊东美咲");
    }
}
