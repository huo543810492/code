package Theory.GenericInterface;

public interface GenericInterface1<T> {
    public  abstract void method(T t);
}
