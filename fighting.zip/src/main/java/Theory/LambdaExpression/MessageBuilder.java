package Theory.LambdaExpression;

public interface MessageBuilder {
    String getMessage();
}
