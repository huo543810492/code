package Theory.AOP;

public class OriginalClass {
    public void method(){
        System.out.println("business logic completed");

    }
}
