package Theory.AnonymousInnerClass;

public interface MyInterface {
    void method();
}
