package Theory.TestConstructor;

public class Maindemo {
    public static void main(String[] args) {
        Child c =new Child("大白",25);
    }
}
