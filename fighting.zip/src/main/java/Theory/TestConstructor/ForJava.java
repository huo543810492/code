package Theory.TestConstructor;

public class ForJava {

}
