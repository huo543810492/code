package Theory.FunctionalInterface;

public interface MyFunctionalInterface {
    public abstract void MessageBuilder();
}
