package Theory.lambdaPractice;

public interface Cook {
    public abstract void  makeFood();
}
