//package Theory.FatherChildTest;
//
//public class child extends Father {
//    public static void main(String[] args) {
//        //子类可直接使用父类protected 变量不用加super
//        System.out.println(a.contains("b"));
//        StringBuilder a = new StringBuilder();
//        a.append("aaa");
//        System.out.println(a.toString());
//        System.out.println(student);
//    }
//}
