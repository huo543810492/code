//package Theory.FatherChildTest;
//
//import testNewObjectInLoop.Student;
//
//public class Father {
//    protected static String a = "aaa";
//    public static Student student= new Student("bai",18);
//
//    public String getA() {
//        return a;
//    }
//
//    public void setA(String a) {
//        this.a = a;
//    }
//}
