package Theory.ExceptionPractice;

public class RegisterException extends Exception {
    public RegisterException(){
        super();
    }
    public RegisterException(String message){
        super(message);
    }
}
