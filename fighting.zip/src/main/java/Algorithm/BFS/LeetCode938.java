package Algorithm.BFS;

public class LeetCode938 {
//    int result;
//    public int rangeSumBST(TreeNode root, int low, int high) {
//        if(root == null)
//            return 0;
//        Queue<TreeNode> queue = new LinkedList<>();
//        queue.add(root);
//        bfs(low,high,queue);
//        return result;
//    }
//
//public void bfs(Queue<TreeNode> queue,int low,int high)
//{
//    while(queue.size()!=0)
//    {
//        TreeNode curr=queue.poll();
//        if(curr.val>=low && curr.val<=high)
//            result+=curr.val;
//        if(curr.left!=null && curr.val>low)　//第二个条件是优化
//        queue.add(curr.left);
//        if(curr.right!=null && curr.val<high) //第二个条件是优化
//            queue.add(curr.right);
//    }
//}
}
