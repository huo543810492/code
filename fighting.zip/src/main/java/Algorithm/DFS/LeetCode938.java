package Algorithm.DFS;

public class LeetCode938 {
//    int result;
//    public int rangeSumBST(TreeNode root, int low, int high) {
//        if(root == null)
//            return 0;
//        dfs(root,low,high);
//        return result;
//    }
//    public void dfs(TreeNode curr,int low, int high){
//        if(curr==null)
//            return;
//        if(curr.val>=low && curr.val<=high){
//            result = result + curr.val;
//        }
//        if(curr.val>low)//剪枝
//            dfs(curr.left,low,high);
//        if(curr.val<high)
//            dfs(curr.right,low,high);
//    }
}
