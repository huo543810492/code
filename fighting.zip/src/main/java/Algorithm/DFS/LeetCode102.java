package Algorithm.DFS;

public class LeetCode102 {
//    public List<List<Integer>> levelOrder(TreeNode root) {
//        List<List<Integer>> result = new ArrayList<>();
//        if(root == null)
//            return result;
//        dfs(result,root,0);
//        return result;
//    }
//
//public void dfs(List<List<Integer>>result,TreeNode curr,int level){
//    if(curr==null)
//        return;
//    if(level>result.size()-1)//如果到了一个新的level，先创建一个空的list，方便之后通过level往里面放值
//        result.add(new ArrayList<>());
//    result.get(level).add(curr.val);//level关键
//    dfs(result,curr.left,level+1);
//    dfs(result,curr.right,level+1);
//}
}
