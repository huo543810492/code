package Algorithm.TwoPointer;

public class LeetCode141 {
//    public boolean hasCycle(ListNode head) {
//        ListNode slow = new ListNode();
//        ListNode fast = new ListNode();
//        if(head == null)  //注意特殊情况的判断
//            return false;
//        slow = head;
//        fast = head.next;
//        while(slow != null && fast != null){  //注意当两个指针都为空，也有可能相等，所以要判断
//            if(slow == fast)   //注意要先判断是否相等
//                return true;
//            slow = slow.next;
//            if(fast.next != null){ //注意特殊情况的判断
//                fast = fast.next.next;
//            }
//            else return false;
//
//        }
//        return false;
//    }
}
