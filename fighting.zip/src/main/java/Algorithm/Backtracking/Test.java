package Algorithm.Backtracking;

public class Test {
    public static void main(String[] args) {
        String a="a";
        a.concat("b");
        System.out.println(a);//a
        a=a.concat("b");
        System.out.println(a);//ab
    }
}
