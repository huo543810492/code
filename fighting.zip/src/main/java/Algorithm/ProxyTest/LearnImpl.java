package Algorithm.ProxyTest;

public class LearnImpl implements Learn {
    public void howToLearn() {
        System.out.println("keep fighting");
    }
}
