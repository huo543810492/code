package Algorithm.ProxyTest;

public interface Learn

{
    void howToLearn();
}
