package Algorithm.Top100LikedQuestions;

public class LeetCode101 {
//    public boolean isSymmetric(TreeNode root) {
//        return isMirror(root,root);
//    }
//    private boolean isMirror(TreeNode t1,TreeNode t2)
//    {
//        if(t1==null && t2==null)
//            return true;
//        if(t1==null || t2==null) //一个为空，一个不为空
//            return false;
//        return (t1.val==t2.val) && isMirror(t1.left,t2.right)  && isMirror(t1.right,t2.left);
//    }
}
