package Algorithm.Top100LikedQuestions;

public class LeetCode236 {
//    public TreeNode lowestCommonAncestor(TreeNode root, TreeNode p, TreeNode q) {
//        if (root == null || root == p || root == q)
//            return root;
//        TreeNode left = lowestCommonAncestor(root.left, p, q);
//        TreeNode right = lowestCommonAncestor(root.right, p, q);

//        if(left != null && right != null) //并不包含
//            return root;
//        return left == null ? right : left;//一个节点包含另一个
//    }
}
