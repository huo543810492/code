package Algorithm.Top100LikedQuestions;

public class LeetCode24 {
//    public ListNode swapPairs(ListNode head) {
//        ListNode dummy = new ListNode();
//        dummy.next=head;
//        ListNode prev = dummy;
//        while(head!=null && head.next!=null)
//        {
//            //重拍
//            ListNode next = head.next.next;
//            prev.next = head.next;
//            head.next.next = head;
//            head.next = next;
//
//            //准备下一次交换
//            prev = head;
//            head = next;
//
//        }
//        return dummy.next;
//    }
}
