package Algorithm.Top100LikedQuestions;

public class LeetCode104 {

//    Integer res=0;
//    public int maxDepth(TreeNode root) {
//        if(root==null)
//            return 0;
//        helper(root,1);
//        return res;
//    }
//    private void helper(TreeNode root,int count)
//    {
//        if(root==null)
//            return;
//        res=Math.max(res,count); //巧妙点，count在return后会自动减一
//        helper(root.left,count+1);
//        helper(root.right,count+1);
//    }

}
