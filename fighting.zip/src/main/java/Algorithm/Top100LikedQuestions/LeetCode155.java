package Algorithm.Top100LikedQuestions;

import java.util.Stack;

public class LeetCode155 {
//    private Stack<Integer> stack;
//    private Stack<Integer> minStack;
//    public MinStack() {
//        stack=new Stack<>();
//        minStack=new Stack<>();
//    }
//
//    public void push(int val) {
//        if(minStack.isEmpty()||minStack.peek()>=val)
//            minStack.push(val);
//        stack.push(val);
//    }
//
//    public void pop() {
//        if(minStack.peek().equals(stack.peek()))
//            minStack.pop();
//        stack.pop();
//    }
//
//    public int top() {
//        return stack.peek();
//    }
//
//    public int getMin() {
//        return minStack.peek();
//    }
}
