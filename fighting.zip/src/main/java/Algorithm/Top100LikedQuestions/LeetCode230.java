package Algorithm.Top100LikedQuestions;

public class LeetCode230 {
//    public int kthSmallest(TreeNode root, int k) {
//        int res=0;
//        PriorityQueue<Integer> minHeap=new PriorityQueue<>();
//        helper(minHeap,root);
//        for(int i=0;i<k;i++){
//            res=minHeap.poll();
//        }
//        return res;
//    }
//
//    public void helper(PriorityQueue<Integer> minHeap,TreeNode root){
//        if(root==null)
//            return;
//        minHeap.add(root.val);
//        helper(minHeap,root.left);
//        helper(minHeap,root.right);
//    }
}
