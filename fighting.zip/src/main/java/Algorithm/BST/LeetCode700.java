package Algorithm.BST;

public class LeetCode700 {
//    public TreeNode searchBST(TreeNode root, int val) {
//        if (root == null || val == root.val) return root;
//
//        return val < root.val ? searchBST(root.left, val) : searchBST(root.right, val);
//    }
}
